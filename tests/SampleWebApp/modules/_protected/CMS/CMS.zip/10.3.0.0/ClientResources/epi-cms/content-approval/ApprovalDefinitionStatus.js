//>>built
define("epi-cms/content-approval/ApprovalDefinitionStatus",{enabled:0,disabled:1,inherited:2});